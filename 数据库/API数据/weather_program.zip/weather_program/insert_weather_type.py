import json
import pymysql


def get_data():
    with open('/home/tarena/weather_type.json', 'r') as f:
        weather_type_text = json.load(f)  # 解析每一行数据
    return weather_type_text
def data_insert(weather_type_text):
    conn = pymysql.connect(
        host='localhost',  # mysql服务器地址
        port=3306,  # 端口号
        user='root',  # 用户名
        passwd='123456',  # 密码
        db='weather',  # 数据库名称
        charset='utf8',  # 连接编码，根据需要填写
    )
    cur = conn.cursor()
    # print(type(weather_type_text))
    for i in range(33):
        value_lo = ((weather_type_text['result'][i]['wid'],
                     weather_type_text['result'][i]['weather'],
                     ))
        insert_lo = "insert into weather_type(wid,weather)" \
                    " values (%s,%s)"
        cur.execute(insert_lo, value_lo)
        conn.commit()
    # print(value_lo)
    cur.close()
    conn.close()
    '''except Exception as e:
        db.rollback()
        print(str(e))
        break'''


if __name__ == "__main__":  # 起到一个初始化或者调用函数的作用
    a = get_data()
    data_insert(a)
