
import requests
import json,pymysql

class WeatherAPI(object):
    def __init__(self):
        self.url = 'http://v.juhe.cn/weather/index'
        self.db = pymysql.connect(
            host='localhost' ,
            port=3306 ,
            user='root' ,
            passwd='123456' ,
            db='weather' ,
            charset='utf8' ,
        )
        self.cursor = self.db.cursor()
    # 获取请求
    def get_html(self,url):
        city = input('请输入您想查询的城市名:')
        params = {
            'cityname': '%s'%city ,
            'dtype': 'json' ,
            'key': 'c16a05e5d7f9c84905d6be01ed51a62d' ,
            'format': '1'
        }
        html = requests.get(
            url=url , params=params
        ).content.decode('utf-8' , 'ignore')
        self.parse_html_json(html)
    # json解析
    def parse_html_json(self,html):
        data = json.loads(html)
        self.insert_data(data)
    def insert_data(self,weather_text):
        L = ((       weather_text['result']['today']['city'] ,
                     weather_text['result']['today']['date_y'] ,
                     weather_text['result']['today']['week'] ,
                     weather_text['result']['today']['temperature'] ,
                     weather_text['result']['today']['weather'] ,
                     weather_text['result']['today']['wind'] ,
                     weather_text['result']['today']['dressing_index'] ,
                     # weather_text['result']['today']['dressing_advice'],
                     weather_text['result']['today']['uv_index'] ,
                     weather_text['result']['today']['wash_index'] ,
                     ))
        ins = 'insert into today_weather (city,date,week,temperature,weather,wind,dressing_index,uv_index,wash_index) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        try:
            self.cursor.execute(ins,L)
            self.db.commit()
        except Exception as e:
            print(e)
            self.db.rollback()
    def run(self):
        self.get_html(self.url)
        self.cursor.close()
        self.db.close()
if __name__ == '__main__':
    api = WeatherAPI()
    api.run()