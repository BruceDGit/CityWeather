import json
import pymysql


def get_data():
    with open('/home/tarena/city_list.json', 'r') as f:
        city_list_text = json.load(f)  # 解析每一行数据
    return city_list_text
def data_insert(city_list_text):
    conn = pymysql.connect(
        host='localhost',  # mysql服务器地址
        port=3306,  # 端口号
        user='root',  # 用户名
        passwd='123456',  # 密码
        db='weather',  # 数据库名称
        charset='utf8',  # 连接编码，根据需要填写
    )
    cur = conn.cursor()
    # print(type(city_list_text))
    for i in range(2594):
        value_lo = ((city_list_text['result'][i]['id'],
                     city_list_text['result'][i]['province'],
                     city_list_text['result'][i]['city'],
                     city_list_text['result'][i]['district'],
                     ))
        insert_lo = "insert into city_list(id,province,city,district)" \
                    " values (%s,%s,%s,%s)"
        cur.execute(insert_lo, value_lo)
        conn.commit()
    # print(value_lo)
    cur.close()
    conn.close()
    '''except Exception as e:
        db.rollback()
        print(str(e))
        break'''


if __name__ == "__main__":  # 起到一个初始化或者调用函数的作用
    a = get_data()
    data_insert(a)
