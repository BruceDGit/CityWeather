#python
import json,urllib
from urllib import parse
from urllib.request import urlopen

url = 'http://api.k780.com'
params = {
  'app' : 'weather.city',
  'appkey' : '45736',
  'sign' : 'e367c583bb98c457d4139d9533182b5c',
  'format' : 'json',
}
params = urllib.parse.urlencode(params)

f = urlopen('%s?%s' % (url, params))
nowapi_call = f.read()
#print content
a_result = json.loads(nowapi_call)
djson=json.dumps(a_result,ensure_ascii=False)
# print(djson)
def jsonFile(fileData):
	file = open("citylist.json","w")
	file.write(fileData)
	file.close()

if __name__ == '__main__':

    jsonFile(djson)