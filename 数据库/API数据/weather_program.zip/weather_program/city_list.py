#python
import json,urllib
from urllib import parse
from urllib.request import urlopen

url = 'http://v.juhe.cn/weather/citys'
params = {
  'dtype' : 'json',
  'key':'c16a05e5d7f9c84905d6be01ed51a62d'
}
params = urllib.parse.urlencode(params)

f = urlopen('%s?%s' % (url, params))
nowapi_call = f.read()
#print content
a_result = json.loads(nowapi_call)
djson=json.dumps(a_result,ensure_ascii=False)
print(djson)