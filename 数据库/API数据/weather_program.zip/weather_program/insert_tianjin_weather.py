import json
import pymysql


def get_data():
    with open('/home/tarena/tianjin.json', 'r') as f:
        weather_text = json.load(f)  # 解析每一行数据
    return weather_text
def data_insert(weather_text):
    conn = pymysql.connect(
        host='localhost',  # mysql服务器地址
        port=3306,  # 端口号
        user='root',  # 用户名
        passwd='123456',  # 密码
        db='weather',  # 数据库名称
        charset='utf8',  # 连接编码，根据需要填写
    )
    cur = conn.cursor()
    # print(type(weather_type_text))
    value_lo = ((weather_text['result']['today']['city'],
                 weather_text['result']['today']['date_y'],
                 weather_text['result']['today']['week'],
                 weather_text['result']['today']['temperature'],
                 weather_text['result']['today']['weather'],
                 weather_text['result']['today']['wind'],
                 weather_text['result']['today']['dressing_index'],
                 # weather_text['result']['today']['dressing_advice'],
                 weather_text['result']['today']['uv_index'],
                 weather_text['result']['today']['wash_index'],
                 weather_text['result']['today']['travel_index'],
                 weather_text['result']['today']['exercise_index'],
                 ))
    insert_lo = "insert into today_weather(city,date,week,temperature,weather,wind,dressing_index,uv_index,wash_index,)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cur.execute(insert_lo, value_lo)
    conn.commit()
    # print(value_lo)
    cur.close()
    conn.close()
    '''except Exception as e:
        db.rollback()
        print(str(e))
        break'''


if __name__ == "__main__":  # 起到一个初始化或者调用函数的作用
    a = get_data()
    data_insert(a)
