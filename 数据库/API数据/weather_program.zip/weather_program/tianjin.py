#python
import json,urllib
from urllib import parse
from urllib.request import urlopen

url = 'http://api.k780.com'
params = {
  'app' : 'weather.today',
  'weaid' : '2743',
  'appkey' : '45736',
  'sign' : '20a5fff15c71f295270b9f54d68b24a7',
  'format' : 'json',
}
params = urllib.parse.urlencode(params)

f = urlopen('%s?%s' % (url, params))
nowapi_call = f.read()
#print content
a_result = json.loads(nowapi_call)
djson=json.dumps(a_result,ensure_ascii=False)
# print(djson)
def jsonFile(fileData):
	file = open("tianjin_today.json","w")
	file.write(fileData)
	file.close()

if __name__ == '__main__':

    jsonFile(djson)